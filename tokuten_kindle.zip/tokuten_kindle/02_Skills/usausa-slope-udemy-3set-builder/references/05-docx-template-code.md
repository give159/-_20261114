# 受講生用ワークブック・講師用台本 テンプレートコード（docx）

このコードは動作確認済み（Figma×Notion編、AI×Notion編、分岐型ストーリーゲーム編で実際に使用）。
`stages配列` と `MAIN_TITLE` / `FOOTER_TEACHER` / `FOOTER_STUDENT` だけ差し替えれば、新しいテーマでそのまま動く。

先に `/mnt/skills/public/docx/SKILL.md` を読むこと。

```javascript
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, ShadingType, HeadingLevel, BorderStyle, AlignmentType,
  PageOrientation, Header, Footer, PageNumber,
} = require("docx");

const NAVY="21295C", DEEP="065A82", TEAL="1C7293", LIGHTBG="F4F8FA", LINEC="DCE6EC", RED="B85042";

// ▼▼▼ ここをテーマごとに差し替える ▼▼▼
const MAIN_TITLE = "分岐型ストーリーゲームの作り方（エンジニア向け実践編）";
const FOOTER_TEACHER = "講師用台本｜分岐型ストーリーゲームの作り方";
const FOOTER_STUDENT = "受講生用｜分岐型ストーリーゲームの作り方";
const INTRO_TEACHER = "データ駆動設計で「選択肢によって分岐する学習ゲーム」のエンジンを、自分の手でゼロから実装する力を、8段階の坂道設計で習得します。";
const INTRO_STUDENT = "この教材では、データ駆動設計で「選択肢によって分岐する学習ゲーム」のエンジンを、あなた自身の手でゼロから実装します。各ステップを順番に進めてください。";

const stages = [
  { n:1, zone:"助走ゾーンA", title:"...", time:"0:00–0:08", level:"難易度 1", goal:"...",
    teacher:[ {t:"0:00", s:"...", n:"..."}, /* 2〜4本 */ ],
    student:[ "...", /* 2〜4個 */ ] },
  // n:2〜8 まで、02-stage-design-guide.md のテンプレート通りに埋める
  // 山場（n:7）の teacher 配列には、s の先頭に "★" を付けた行を2本含める
];
const CHECKLIST = ["...", "...", "...", "...", "..."]; // 5項目
// ▲▲▲ ここまで差し替え ▲▲▲

function cell(text, opts={}) {
  const {width, bold=false, color="1A2233", size=20, shade=null, align=AlignmentType.LEFT, italics=false} = opts;
  return new TableCell({
    width:{size:width, type:WidthType.DXA},
    shading: shade ? {type:ShadingType.CLEAR, fill:shade} : undefined,
    margins:{top:100,bottom:100,left:120,right:120},
    children:[new Paragraph({alignment:align, children:[new TextRun({text,bold,italics,color,size})]})],
  });
}

// ===== 講師用台本（横向き / 時刻・セリフ・ねらいの3列表）=====
function buildTeacherDoc(){
  const headerRow = new TableRow({tableHeader:true, children:[
    cell("時刻",{width:1000,bold:true,color:"FFFFFF",shade:NAVY,align:AlignmentType.CENTER}),
    cell("セリフ例・進行",{width:6200,bold:true,color:"FFFFFF",shade:NAVY}),
    cell("ねらい・進行メモ",{width:3800,bold:true,color:"FFFFFF",shade:NAVY}),
  ]});
  const children = [];
  children.push(new Paragraph({heading:HeadingLevel.TITLE, spacing:{after:80},
    children:[new TextRun({text:MAIN_TITLE, bold:true, color:NAVY, size:36})]}));
  children.push(new Paragraph({spacing:{after:60},
    children:[new TextRun({text:"講師用台本（全8段階・スロープ設計／所要時間 約1時間45分）", bold:true, color:TEAL, size:26})]}));
  children.push(new Paragraph({spacing:{after:300},
    children:[new TextRun({text:INTRO_TEACHER, color:"444444", size:20, italics:true})]}));

  // 全体タイムテーブル
  children.push(new Paragraph({heading:HeadingLevel.HEADING_1, spacing:{before:100,after:120},
    children:[new TextRun({text:"全体タイムテーブル", bold:true, color:NAVY, size:26})]}));
  const ttHeader = new TableRow({tableHeader:true, children:[
    cell("段階",{width:900,bold:true,color:"FFFFFF",shade:DEEP,align:AlignmentType.CENTER}),
    cell("ゾーン",{width:2000,bold:true,color:"FFFFFF",shade:DEEP}),
    cell("内容",{width:4400,bold:true,color:"FFFFFF",shade:DEEP}),
    cell("時間",{width:1400,bold:true,color:"FFFFFF",shade:DEEP,align:AlignmentType.CENTER}),
    cell("難易度",{width:1300,bold:true,color:"FFFFFF",shade:DEEP,align:AlignmentType.CENTER}),
  ]});
  const ttRows = stages.map((s,i)=>new TableRow({children:[
    cell(String(s.n),{width:900,bold:true,color:NAVY,shade:i%2?LIGHTBG:"FFFFFF",align:AlignmentType.CENTER}),
    cell(s.zone,{width:2000,color:s.zone.includes("頂上")?RED:"1A2233",bold:s.zone.includes("頂上"),shade:i%2?LIGHTBG:"FFFFFF"}),
    cell(s.title,{width:4400,shade:i%2?LIGHTBG:"FFFFFF"}),
    cell(s.time,{width:1400,align:AlignmentType.CENTER,shade:i%2?LIGHTBG:"FFFFFF"}),
    cell(s.level,{width:1300,align:AlignmentType.CENTER,shade:i%2?LIGHTBG:"FFFFFF"}),
  ]}));
  children.push(new Table({width:{size:10000,type:WidthType.DXA}, columnWidths:[900,2000,4400,1400,1300], rows:[ttHeader,...ttRows]}));
  children.push(new Paragraph({text:"",spacing:{after:200}}));

  // 段階ごとのセクション
  stages.forEach(s=>{
    children.push(new Paragraph({heading:HeadingLevel.HEADING_1, spacing:{before:260,after:60},
      children:[new TextRun({text:`段階${s.n}　${s.zone}：${s.title}`, bold:true, color:s.zone.includes("頂上")?RED:NAVY, size:26})]}));
    children.push(new Paragraph({spacing:{after:40},
      children:[new TextRun({text:`${s.time}　／　${s.level}`, bold:true, color:TEAL, size:20})]}));
    children.push(new Paragraph({spacing:{after:140},
      children:[new TextRun({text:`ねらい：${s.goal}`, italics:true, color:"444444", size:20})]}));
    const rows = s.teacher.map(r=>new TableRow({children:[
      cell(r.t,{width:1000,align:AlignmentType.CENTER,bold:true,color:DEEP}),
      cell(r.s,{width:6200,color:r.s.startsWith("★")?RED:"1A2233",bold:r.s.startsWith("★")}),
      cell(r.n,{width:3800,color:"555555"}),
    ]}));
    children.push(new Table({width:{size:11000,type:WidthType.DXA}, columnWidths:[1000,6200,3800], rows:[headerRow,...rows]}));
    children.push(new Paragraph({text:"",spacing:{after:120}}));
  });

  // チェックリスト
  children.push(new Paragraph({heading:HeadingLevel.HEADING_1, spacing:{before:300,after:140},
    children:[new TextRun({text:"振り返りチェックリスト（段階8で使用）", bold:true, color:NAVY, size:26})]}));
  CHECKLIST.forEach(c=>children.push(new Paragraph({spacing:{after:80},
    children:[new TextRun({text:`□ ${c}`, size:22, color:"1A2233"})]})));

  return new Document({sections:[{
    properties:{page:{size:{width:16838,height:11906,orientation:PageOrientation.LANDSCAPE}, margin:{top:900,bottom:900,left:900,right:900}}},
    headers:{default:new Header({children:[new Paragraph({alignment:AlignmentType.RIGHT,
      children:[new TextRun({text:FOOTER_TEACHER, size:16, color:"888888"})]})]})},
    footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,
      children:[new TextRun({text:"うさうさ研修工房　", size:16, color:"999999"}), new TextRun({children:[PageNumber.CURRENT], size:16, color:"999999"})]})]})},
    children,
  }]});
}

// ===== 受講生用ワークブック（縦向き / 二人称の番号リスト）=====
function buildStudentDoc(){
  const children = [];
  children.push(new Paragraph({heading:HeadingLevel.TITLE, spacing:{after:80},
    children:[new TextRun({text:MAIN_TITLE, bold:true, color:NAVY, size:36})]}));
  children.push(new Paragraph({spacing:{after:60},
    children:[new TextRun({text:"受講生用ワークブック（全8段階・所要時間 約1時間45分）", bold:true, color:TEAL, size:26})]}));
  children.push(new Paragraph({spacing:{after:300},
    children:[new TextRun({text:INTRO_STUDENT, color:"444444", size:20, italics:true})]}));

  stages.forEach(s=>{
    children.push(new Paragraph({heading:HeadingLevel.HEADING_1, spacing:{before:280,after:60},
      border:{bottom:{style:BorderStyle.SINGLE,size:6,color:LINEC}},
      children:[new TextRun({text:`STEP ${s.n}　${s.title}`, bold:true, color:s.zone.includes("頂上")?RED:NAVY, size:26})]}));
    children.push(new Paragraph({spacing:{after:40},
      children:[new TextRun({text:`${s.zone}　／　目安時間：${s.time}`, bold:true, color:TEAL, size:19})]}));
    children.push(new Paragraph({spacing:{after:140},
      children:[new TextRun({text:`今回のゴール：${s.goal}`, italics:true, color:"444444", size:20})]}));
    s.student.forEach((step,i)=>children.push(new Paragraph({spacing:{after:90}, indent:{left:260},
      children:[new TextRun({text:`${i+1}. ${step}`, size:22, color:"1A2233"})]})));
  });

  children.push(new Paragraph({heading:HeadingLevel.HEADING_1, spacing:{before:320,after:140},
    border:{bottom:{style:BorderStyle.SINGLE,size:6,color:LINEC}},
    children:[new TextRun({text:"振り返りチェックリスト", bold:true, color:NAVY, size:26})]}));
  CHECKLIST.forEach(c=>children.push(new Paragraph({spacing:{after:90},
    children:[new TextRun({text:`□ ${c}`, size:22, color:"1A2233"})]})));

  return new Document({sections:[{
    properties:{page:{size:{width:11906,height:16838}, margin:{top:1000,bottom:1000,left:1100,right:1100}}},
    headers:{default:new Header({children:[new Paragraph({alignment:AlignmentType.RIGHT,
      children:[new TextRun({text:FOOTER_STUDENT, size:16, color:"888888"})]})]})},
    footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,
      children:[new TextRun({text:"うさうさ研修工房　", size:16, color:"999999"}), new TextRun({children:[PageNumber.CURRENT], size:16, color:"999999"})]})]})},
    children,
  }]});
}

async function main(){
  fs.writeFileSync("/home/claude/teacher.docx", await Packer.toBuffer(buildTeacherDoc()));
  fs.writeFileSync("/home/claude/student.docx", await Packer.toBuffer(buildStudentDoc()));
  console.log("done");
}
main();
```

## 生成後の手順（毎回必須）

1. `node build.js` で両方生成
2. `python3 /mnt/skills/public/docx/scripts/office/validate.py teacher.docx` と `student.docx` の両方
3. `soffice.py --headless --convert-to pdf` → `pdftoppm` でJPEG化 → 全ページを `view` で目視確認（表がページをまたいで崩れていないか、★の赤字が効いているか）
