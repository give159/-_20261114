# 受講生用PPT テンプレートコード（pptxgenjs）

このコードは動作確認済み（Figma×Notion編、AI×Figma編、分岐型ストーリーゲーム編で実際に使用）。
`STAGES配列` と `TITLE_MAIN` / `SUBTITLE` / `FOOTER_LABEL` だけ差し替えれば、新しいテーマでそのまま動く。

先に `/mnt/skills/public/pptx/SKILL.md` を読むこと。

```javascript
const pptxgen = require("pptxgenjs");
const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE";

const NAVY="21295C", DEEP="065A82", TEAL="1C7293", MINT="5FBDB0",
      WHITE="FFFFFF", OFFWHITE="F4F8FA", INK="1A2233", MUTED="6B7A8F",
      LINE="DCE6EC", RED="B85042";
const FONT_HEAD="Cambria", FONT_BODY="Calibri";
const W=13.333, H=7.5;

// ▼▼▼ ここをテーマごとに差し替える ▼▼▼
const TITLE_MAIN = "分岐型ストーリーゲーム\nの作り方";       // 表紙の大見出し（改行可）
const SUBTITLE_TAG = "エンジニア向け実践編";                  // 表紙上部の小ラベル
const SUBTITLE_LINE = "全8段階・スロープ設計／所要時間 約1時間45分";
const DESCRIPTION = "データ駆動設計で、選択肢によって分岐する学習ゲームのエンジンを自分の手で実装する";
const FOOTER_LABEL = "分岐型ストーリーゲームの作り方｜エンジニア向け実践編"; // 各スライド左下

const stages = [
  { n:1, zone:"助走ゾーンA", title:"...", time:"0:00–0:08", level:1, goal:"...",
    steps:["...", "..."] },
  // n:2〜8 まで、02-stage-design-guide.md のテンプレート通りに埋める
];
const CHECKLIST = ["...", "...", "...", "...", "..."]; // 5項目
// ▲▲▲ ここまで差し替え ▲▲▲

function bgDark(s){ s.background={color:NAVY}; }
function bgLight(s){ s.background={color:WHITE}; }
function footer(s,n,label){
  s.addText(label,{x:0.5,y:H-0.42,w:8,h:0.3,fontFace:FONT_BODY,fontSize:9,color:MUTED,isTextBox:true,margin:0});
  s.addText(String(n),{x:W-1.0,y:H-0.42,w:0.5,h:0.3,fontFace:FONT_BODY,fontSize:9,color:MUTED,align:"right",isTextBox:true,margin:0});
}
function tag(s,text,color){
  s.addText(text.toUpperCase(),{x:0.6,y:0.45,w:6,h:0.35,fontFace:FONT_BODY,fontSize:12,bold:true,color,charSpacing:2,isTextBox:true,margin:0});
}
function title(s,text,opts={}){
  s.addText(text,{x:0.6,y:opts.y||0.78,w:opts.w||11.9,h:opts.h||0.9,fontFace:FONT_HEAD,fontSize:opts.size||26,bold:true,color:opts.color||NAVY,isTextBox:true,margin:0});
}
function badge(s,x,y,w,text,color){
  s.addShape("roundRect",{x,y,w,h:0.36,rectRadius:0.18,fill:{color},line:{type:"none"}});
  s.addText(text,{x,y,w,h:0.36,align:"center",valign:"middle",fontFace:FONT_BODY,fontSize:11,bold:true,color:WHITE,isTextBox:true,margin:0});
}

// ---- Slide 1: Cover ----
{
  const s = pres.addSlide(); bgDark(s);
  s.addShape("roundRect",{x:9.7,y:1.1,w:3.0,h:3.0,rectRadius:0.18,fill:{color:DEEP,transparency:55},line:{type:"none"}});
  s.addShape("roundRect",{x:10.6,y:3.5,w:2.2,h:2.2,rectRadius:0.18,fill:{color:TEAL,transparency:40},line:{type:"none"}});
  s.addShape("roundRect",{x:9.2,y:4.9,w:1.6,h:1.6,rectRadius:0.14,fill:{color:MINT,transparency:55},line:{type:"none"}});
  s.addText(SUBTITLE_TAG,{x:0.8,y:2.0,w:8.6,h:0.5,fontFace:FONT_BODY,fontSize:16,bold:true,color:MINT,charSpacing:1,isTextBox:true,margin:0});
  s.addText(TITLE_MAIN,{x:0.75,y:2.45,w:9.5,h:2.0,fontFace:FONT_HEAD,fontSize:40,bold:true,color:WHITE,lineSpacingMultiple:1.08,isTextBox:true,margin:0});
  s.addText(SUBTITLE_LINE,{x:0.8,y:4.65,w:8.6,h:0.5,fontFace:FONT_BODY,fontSize:16,color:OFFWHITE,isTextBox:true,margin:0});
  s.addShape("line",{x:0.8,y:5.25,w:2.4,h:0,line:{color:MINT,width:2}});
  s.addText(DESCRIPTION,{x:0.8,y:5.5,w:8.0,h:0.9,fontFace:FONT_BODY,fontSize:12.5,italic:true,color:OFFWHITE,isTextBox:true,margin:0});
  s.addText("うさうさ研修工房",{x:0.8,y:6.9,w:6,h:0.4,fontFace:FONT_BODY,fontSize:12,color:MUTED,isTextBox:true,margin:0});
}

// ---- Slide 2: ロードマップ（難易度の棒グラフ） ----
{
  const s = pres.addSlide(); bgLight(s);
  tag(s,"Roadmap",DEEP);
  title(s,"今日のゴールと8段階の流れ");
  s.addText("難易度は少しずつ上がり、STEP7の「山場」でピークに達したあと、STEP8で振り返って着地します",
    {x:0.6,y:1.65,w:12.0,h:0.4,fontFace:FONT_BODY,fontSize:13,color:MUTED,italic:true,isTextBox:true,margin:0});
  const chartX=0.7, chartW=11.9, baseY=6.3, maxH=3.6, maxLevel=9;
  stages.forEach((st,i)=>{
    const barW = chartW/stages.length - 0.18;
    const x = chartX + i*(chartW/stages.length) + 0.09;
    const h = (st.level/maxLevel)*maxH;
    const y = baseY - h;
    const isPeak = st.zone.includes("頂上");
    const color = isPeak ? RED : (i<2 ? MINT : (i<6 ? TEAL : DEEP));
    s.addShape("roundRect",{x,y,w:barW,h,rectRadius:0.06,fill:{color},line:{type:"none"}});
    s.addText(`STEP${st.n}`,{x,y:y-0.32,w:barW,h:0.28,align:"center",fontFace:FONT_BODY,fontSize:10.5,bold:true,color:isPeak?RED:NAVY,isTextBox:true,margin:0});
    s.addText(String(st.level),{x,y:y+0.03,w:barW,h:0.3,align:"center",fontFace:FONT_BODY,fontSize:11,bold:true,color:WHITE,isTextBox:true,margin:0});
  });
  s.addShape("line",{x:chartX,y:baseY,w:chartW,h:0,line:{color:LINE,width:1.5}});
  s.addText("難易度（1〜9）",{x:chartX,y:baseY+0.08,w:3,h:0.3,fontFace:FONT_BODY,fontSize:10,color:MUTED,isTextBox:true,margin:0});
  footer(s,2,FOOTER_LABEL);
}

// ---- Slides 3-10: STEP 1-8 ----
stages.forEach((st,idx)=>{
  const s = pres.addSlide(); bgLight(s);
  const isPeak = st.zone.includes("頂上");
  tag(s,`Step ${st.n} / 8`, isPeak?RED:TEAL);
  title(s, st.title, {color: isPeak?RED:NAVY});
  badge(s,0.6,1.65,2.6,st.zone, isPeak?RED:DEEP);
  badge(s,3.35,1.65,2.0,`⏱ ${st.time}`,TEAL);
  badge(s,5.5,1.65,1.8,`難易度 ${st.level}`, isPeak?RED:MUTED);
  s.addShape("roundRect",{x:0.6,y:2.35,w:12.1,h:0.75,rectRadius:0.08,fill:{color:OFFWHITE},line:{color:LINE,width:1}});
  s.addText(`ねらい：${st.goal}`,{x:0.85,y:2.35,w:11.6,h:0.75,valign:"middle",fontFace:FONT_BODY,fontSize:13,italic:true,color:INK,isTextBox:true,margin:0});
  const y0=3.35, rowH=(6.7-y0)/st.steps.length;
  st.steps.forEach((stepText,i)=>{
    const y = y0 + i*rowH;
    s.addShape("ellipse",{x:0.6,y:y+0.05,w:0.55,h:0.55,fill:{color:isPeak?RED:DEEP},line:{type:"none"}});
    s.addText(String(i+1),{x:0.6,y:y+0.05,w:0.55,h:0.55,align:"center",valign:"middle",fontFace:FONT_BODY,fontSize:16,bold:true,color:WHITE,isTextBox:true,margin:0});
    s.addText(stepText,{x:1.35,y:y,w:11.3,h:rowH,valign:"middle",fontFace:FONT_BODY,fontSize:13.5,color:INK,lineSpacingMultiple:1.2,isTextBox:true,margin:0});
  });
  footer(s, idx+3, FOOTER_LABEL);
});

// ---- Slide 11: 振り返りチェックリスト ----
{
  const s = pres.addSlide(); bgDark(s);
  s.addShape("roundRect",{x:9.6,y:0.8,w:3.1,h:3.1,rectRadius:0.16,fill:{color:DEEP,transparency:55},line:{type:"none"}});
  tag(s,"Summary",MINT);
  title(s,"振り返りチェックリスト",{color:WHITE});
  const y0=2.3;
  CHECKLIST.forEach((c,i)=>{
    const y = y0 + i*0.78;
    s.addShape("roundRect",{x:0.7,y,w:0.4,h:0.4,rectRadius:0.06,fill:{color:NAVY},line:{color:MINT,width:1.5}});
    s.addText(c,{x:1.3,y:y-0.08,w:11.0,h:0.6,valign:"middle",fontFace:FONT_BODY,fontSize:14,color:WHITE,isTextBox:true,margin:0});
  });
  s.addShape("line",{x:0.7,y:6.65,w:3.0,h:0,line:{color:MINT,width:2}});
  s.addText("うさうさ研修工房",{x:0.7,y:6.8,w:6,h:0.4,fontFace:FONT_BODY,fontSize:12,color:MUTED,isTextBox:true,margin:0});
}

pres.writeFile({fileName:"/home/claude/output.pptx"}).then(()=>console.log("done"));
```

## 生成後の手順（毎回必須）

1. `node build.js` で生成
2. `python3 /mnt/skills/public/pptx/scripts/office/validate.py output.pptx`
3. `soffice.py --headless --convert-to pdf` → `pdftoppm` でJPEG化 → 全スライドを `view` で目視確認
4. `markitdown output.pptx | grep -iE "lorem|ipsum|TODO|\\[insert"` でプレースホルダー残留チェック
