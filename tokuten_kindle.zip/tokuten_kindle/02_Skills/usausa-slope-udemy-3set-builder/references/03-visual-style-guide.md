# ビジュアルスタイルガイド（Ocean Gradient）

このシリーズ全体で使ってきた配色・フォント規約。テーマが変わっても、この配色は変えない。

## カラーパレット

```javascript
const NAVY = "21295C";     // 見出し・表紙背景・強調枠
const DEEP = "065A82";     // プライマリカラー（アイコン円・バッジ）
const TEAL = "1C7293";     // セカンダリカラー（タグ・バッジ）
const MINT = "5FBDB0";     // アクセント（チェックリストの枠線など）
const WHITE = "FFFFFF";
const OFFWHITE = "F4F8FA"; // カード背景
const INK = "1A2233";      // 本文テキスト
const MUTED = "6B7A8F";    // キャプション・フッター
const LINE = "DCE6EC";     // 罫線・カード枠線
const RED = "B85042";      // 山場・警告・チェックポイント強調
```

## フォント

- 見出し：`Cambria`（FONT_HEAD）
- 本文：`Calibri`（FONT_BODY）

## PPTレイアウトの型

- `LAYOUT_WIDE`（13.333 × 7.5インチ）
- 表紙：背景NAVY、右側に半透明の角丸四角を3つ重ねた装飾（DEEP/TEAL/MINTのtransparency 40〜55）
- 各スライド左上に `tag()`（セクションラベル、色分けされた大文字英語）＋その下に `title()`
- カード型レイアウトは `roundRect` + `OFFWHITE`背景 + `LINE`枠線
- 番号入りの丸アイコンは `iconCircle()` パターン（ellipse + 中央揃えテキスト、`isTextBox:true, margin:0` を必ずつける）
- フッターは左に講座名、右にページ番号（`footer()`パターン）
- 山場スライドだけ、tagとtitleの色をREDにする

## pptxgenjs実装上の注意点（このユーザーの環境で必須）

- `isTextBox: true, margin: 0` を全てのaddTextに付ける（余白のズレを防ぐため）
- 色は必ず `#` なしの6桁HEX文字列
- 日本語フォントはCambria/Calibriで代替表示されるが、日本語部分は明朝・ゴシック相当にOS側でフォールバックされるため問題ない
- スライド生成前に必ず `/mnt/skills/public/pptx/SKILL.md` を読み、validate.py→PDF化→JPEG化して目視確認する

## Wordドキュメントの型

- 受講生用ワークブック：縦（Portrait）、STEP見出し＋二人称の番号リスト
- 講師用台本：横（LANDSCAPE）、時刻/セリフ例・進行/ねらい・進行メモの3列表
- ヘッダー右揃えで「講師用台本｜〇〇」/「受講生用｜〇〇」、フッター中央に「うさうさ研修工房　<ページ番号>」
- 番号リストは常に `1. 2. 3.` のアラビア数字（黒丸「・」は使わない。ユーザーの標準preference）
- 山場のセリフ行だけ `bold: true, color: RED` にし、先頭に★をつける
